# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import sale_advance_payment
from . import purchase_advance_payment
